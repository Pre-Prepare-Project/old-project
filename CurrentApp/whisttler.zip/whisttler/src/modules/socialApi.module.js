const express = require('express');
const mongoose = require('mongoose');
var influencer = require('../models/influencer.models');
var fbjson=require('../constants/fbdata');
const https = require('https');
  const request = require('request');
var fbdata= function(req,res)
{
request('https://graph.facebook.com/me?fields=id,first_name,last_name,email,friends,hometown,posts.limit(20){description,created_time}&access_token=EAADnzN7e2FABALgcu7znH17D6F9yAZBj5prdvn1og3yn5JIdwIpcKK7LdiRNYkEu6ClyysZBbhFweVkkgQbj3cXZBJfkwUpKqnjd5Ke7cd6geqdOdomr3CnxZA4LsbBgcjlRSBu0ySZBxWs9yAzyNSUgCGA8kfENDIeBYvwDBYB6EyyEBmFEkZCDkUU3V7xZBp33BRldA1qzAZDZD', { json: true }, (err, resp, body) => {
if (err) { return console.log(err); }
res.json(resp.body);
});
}

var saveToken=function(req,res)
{

  if(req.body.platform=="FB")
  {
    var social={"sociallinks.fb":req.body.accessToken};
  }
  else if(req.body.platform=="Instagram"){

    var social={"sociallinks.instagram": req.body.accessToken};
  }

var query={user_id:req.user._id};
  console.log(social);
  influencer.findOneAndUpdate(query,{$set:social},function(err,doc){
    console.log(doc);
    res.status(200).json({"message":"Token stored successfully"});

  });
}

  module.exports={
    fbdata:fbdata,
    saveToken:saveToken

  }
