const express = require('express');
const mongoose = require('mongoose');
var influencer = require('../models/influencer.models');
require('../config/dbconnection');
var Promise = require('promise');

let getinfluencerProfile = function(user) {

  return new Promise(function(resolve, reject) {

    influencer.find({
      user_id: user._id
    },function(err, doc) {
      if (err) {
        reject();
      } else {
        resolve(doc);
      }
    });

  });
};

module.exports = {
  getinfluencerProfile: getinfluencerProfile
};
