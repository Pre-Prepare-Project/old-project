const express = require('express');
const mongoose = require('mongoose');
const socialApiRouter = express.Router();
//const User = require('../models/users.model');
require('../config/dbconnection');
const socialapiModule = require("../modules/socialApi.module");
var consts = require('../constants/statusMessage');

socialApiRouter.get('/',socialapiModule.fbdata);
socialApiRouter.post('/access_token/',socialapiModule.saveToken);

module.exports = socialApiRouter;
