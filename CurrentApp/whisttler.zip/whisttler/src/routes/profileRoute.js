const express = require('express');
const mongoose = require('mongoose');
const profileRouter = express.Router();
//const User = require('../models/users.model');
require('../config/dbconnection');
const profileModule = require("../modules/profile.module");
var consts = require('../constants/statusMessage');

profileRouter.get('/', function(req, res) {

  var role = req.user.role;
  if (role == 'influencer') {
    console.log(req.user);
    profileModule.getinfluencerProfile(req.user)
      .then(function(result) {
        res.status(200).json(result);
      })
      .catch(function() {
        res.status(500).json(consts.ERROR_500);
      });
  } else if (role == 'Brand') {
    res.status(500);
  }

});

module.exports = profileRouter;
