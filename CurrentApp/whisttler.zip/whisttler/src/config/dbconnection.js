const mongoose=require('mongoose');
//mongoose.connect('mongodb+srv://whist:whistller@dbwhistler-dusxa.mongodb.net/dbwhisttler?retryWrites=true');
mongoose.connect('mongodb://localhost:27017/db_whistler');
