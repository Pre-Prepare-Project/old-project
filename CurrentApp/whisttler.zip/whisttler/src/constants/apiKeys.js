/**
 * API Keys Constants File
 * */

export const USERNAME = 'username';
export const PASSWORD = 'password';
export const PHONE = 'phone';
export const EMAIL = 'mail';
export const DOB = 'dob';
export const GENDER = 'sex';
