module.exports={
  "id": "1992129430845433",
  "name": "Nikhil Singhal",
  "friends": {
    "data": [
      {
        "birthday": "11/13/1995",
        "id": "2015177175201640"
      }
    ],
    "paging": {
      "cursors": {
        "before": "QVFIUmhVU1hsUzBMbFdZAVVEwUWloR0NhZAzFCbWtZAbWpEdE5lUGZAVS1k2ZAzhsZAWtOUVlWVzl2R043clhGaTI1SmdVaXRJU1FlZAEdkUHkxNTQyeVlzcUZA4bXdn",
        "after": "QVFIUmhVU1hsUzBMbFdZAVVEwUWloR0NhZAzFCbWtZAbWpEdE5lUGZAVS1k2ZAzhsZAWtOUVlWVzl2R043clhGaTI1SmdVaXRJU1FlZAEdkUHkxNTQyeVlzcUZA4bXdn"
      },
      "next": "https://graph.facebook.com/v3.1/1992129430845433/friends?access_token=EAADnzN7e2FABAHEvMlgfQEcZBvlV8ZC7RakxfPkAjbQNZBVTyofRvz8RWgPwQbk5B58sWOpZCIeSnChy3MXwCUUIOGMjZBoHvtvlyqPvQLJXDo5cVgjrWX01UH6ukfIbUlJ1mKLij20BPw7E5x0dVeHnopLe9SZCQXVTx9qdpUPukaikpWfMlfZCzjtJqoVZBY8ZD&pretty=0&fields=birthday&limit=1&after=QVFIUmhVU1hsUzBMbFdZAVVEwUWloR0NhZAzFCbWtZAbWpEdE5lUGZAVS1k2ZAzhsZAWtOUVlWVzl2R043clhGaTI1SmdVaXRJU1FlZAEdkUHkxNTQyeVlzcUZA4bXdn"
    },
    "summary": {
      "total_count": 692
    }
  },
  "email": "singhal.nikhil.30@gmail.com",
  "first_name": "Nikhil",
  "last_name": "Singhal",
  "hometown": {
    "id": "105634339471550",
    "name": "Muzaffarnagar"
  }
}
