const mongoose = require('mongoose');
var Schema = mongoose.Schema;
var influencerSchema = new Schema({
  user_id: Schema.Types.ObjectId,
  profile: {
    firstname: {
      type: String
    },
    lastname: {
      type: String,
      default: null
    },
    mob: {
      type: String,
      default: null
    },
    email: {
      type: String,
      default: null
    },
    gender: {
      type: String,
      default: null
    },
    Address: {
      add1: {
        type: String,
        default: null
      },
      add2: {
        type: String,
        default: null
      },
      city: {
        type: String,
        default: null
      },
      district: {
        type: String,
        default: null
      },
      pinCode: {
        type: String,
        default: null
      }
    }
  },
  sociallinks: {
    fb: {
      type: String,
      default: null
    },
    twitter: {
      type: String,
      default: null
    },
    youtube: {
      type: String,
      default: null
    },
    instagram: {
      type: String,
      default: null
    }
  }
}, {
  collection: 'influencer-data'
});

module.exports = mongoose.model('influencerData', influencerSchema);
