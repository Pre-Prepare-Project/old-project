module.exports = {
    "extends": "airbnb"
};